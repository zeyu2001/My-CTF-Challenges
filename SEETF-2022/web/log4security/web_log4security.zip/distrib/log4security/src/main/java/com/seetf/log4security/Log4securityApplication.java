package com.seetf.log4security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Log4securityApplication {

	public static void main(String[] args) {
		SpringApplication.run(Log4securityApplication.class, args);
	}

}
